package com.manthan.empwebapp.servletjsp;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/seeAllEmployeeServletJsp")
public class SeeAllEmployeeServlet extends HttpServlet {

}
